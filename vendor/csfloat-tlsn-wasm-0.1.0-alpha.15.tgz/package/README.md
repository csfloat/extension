# TLSNotary WASM Bindings

Derived from [tlsn-wasm-pkg](https://github.com/tlsnotary/tlsn-extension/tree/main/packages/tlsn-wasm-pkg).

This crate provides a WebAssembly package for TLSNotary, offering core functionality for the TLSNotary attestation protocol along with useful TypeScript types.

## Installation

`npm i @csfloat/tlsn-wasm`

## How to Build

Please see the WASM Crate in the TLSN repository [here](https://github.com/tlsnotary/tlsn/tree/main/crates/wasm).

## Links

- [Website](https://tlsnotary.org)
- [Repository](https://github.com/tlsnotary/tlsn)
- [API Docs](https://tlsnotary.github.io/tlsn)